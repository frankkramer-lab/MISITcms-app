#-----------------------------------------------------#
#                   Library imports                   #
#-----------------------------------------------------#

#-----------------------------------------------------#
#              Data Processing Functions              #
#-----------------------------------------------------#
# Read data set in csv function
def read_dataset(path):
    pass

# Data exploration
def exploration(data_set):
    pass

# Preprocess data
def preprocessing(data_set, categorical_variables, binary_variables,
                  numeric_variables):
    pass

# Split data set
def split_dataset(data_set, y_var, test_size=0.2):
    pass
