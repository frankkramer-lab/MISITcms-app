#-----------------------------------------------------#
#                  Evaluation methods                 #
#-----------------------------------------------------#
def confusion_matrix(pred, truth):
    pass

def compute_scores(confusion_mat):
    pass
