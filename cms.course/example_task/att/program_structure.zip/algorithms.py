#-----------------------------------------------------#
#                   Library imports                   #
#-----------------------------------------------------#

#-----------------------------------------------------#
#                 Logistic Regression                 #
#-----------------------------------------------------#
class Logistic_Regression:
    def __init__(self):
        pass

    def train(self, train_x, train_y):
        pass

    def predict(self, data):
        pass
